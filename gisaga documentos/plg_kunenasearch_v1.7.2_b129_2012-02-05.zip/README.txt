/**
* @version $Id$
* Kunena Search Plugin
* @package Kunena Search
*
* @Copyright (C) 2010 www.kunena.com All rights reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @link http://www.kunena.com
*/

Kunena Search Plugin README

PLEASE READ THIS ENTIRE FILE BEFORE INSTALLING Kunena Search 1.7.2!

INTRODUCTION
============

Kunena Search enables your site visitors to see in joomla! search results the things from Kunena.

Requirements: Joomla 1.5, Kunena Forum 1.6

END OF README
=============
