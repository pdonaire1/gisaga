Spanish Translation (es-ES) for
Attachments extension for Joomla 1.5
(http://joomlacode.org/gf/project/attachments/)

Translation by: Manuel María Pérez Ayala (earlier verison by Carlos Alfaro) 

For Attachments version 2.2
Last updated: January 15, 2011
Status: Complete translation

INSTALLATION:
  - Unzip this file in the root directory of your website.
    This will place all of the translation files in the
    correct places.

If you have questions about this translation or want to 
assist with translation, please contact the extension author, 
Jonathan Cameron (jmcameron@jmcameron.net).

Copyright (c) 2007-2010 Jonathan M. Cameron, All Rights Reserved
License: GNU/GPL2, http://www.gnu.org/licenses/gpl-2.0.html 

INSTALLED FILES:
    administrator/components/com_attachments/help/es-ES/help.css
    administrator/components/com_attachments/help/es-ES/help.html
    administrator/components/com_attachments/help/es-ES/index.html
    administrator/language/es-ES/es-ES.com_attachments.ini
    administrator/language/es-ES/es-ES.com_attachments.menu.ini
    administrator/language/es-ES/es-ES.plg_attachments_attachments_for_content.ini
    administrator/language/es-ES/es-ES.plg_attachments_attachments_for_jevents.ini
    administrator/language/es-ES/es-ES.plg_attachments_attachments_for_quickfaq.ini
    administrator/language/es-ES/es-ES.plg_attachments_attachments_plugin_framework.ini
    administrator/language/es-ES/es-ES.plg_content_attachments.ini
    administrator/language/es-ES/es-ES.plg_editors-xtd_add_attachment.ini
    administrator/language/es-ES/es-ES.plg_editors-xtd_insert_attachments_token.ini
    administrator/language/es-ES/es-ES.plg_frontend_attachments.ini
    administrator/language/es-ES/es-ES.plg_search_attachments.ini
    administrator/language/es-ES/es-ES.plg_system_show_attachments.ini
    language/es-ES/es-ES.com_attachments.ini
