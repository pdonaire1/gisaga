Romanian Translation (ro-RO) for
Attachments extension for Joomla 1.5
(http://joomlacode.org/gf/project/attachments/)

Translation by: Alex Cojocaru 

For Attachments version 2.2
Last updated: February 5, 2011
Status: Complete translation

INSTALLATION:
  - Unzip this file in the root directory of your website.
    This will place all of the translation files in the
    correct places.

If you have questions about this translation or want to 
assist with translation, please contact the extension author, 
Jonathan Cameron (jmcameron@jmcameron.net).

Copyright (c) 2007-2010 Jonathan M. Cameron, All Rights Reserved
License: GNU/GPL2, http://www.gnu.org/licenses/gpl-2.0.html 

INSTALLED FILES:
    administrator/components/com_attachments/help/ro-RO/help.css
    administrator/components/com_attachments/help/ro-RO/help.html
    administrator/components/com_attachments/help/ro-RO/index.html
    administrator/language/ro-RO/ro-RO.com_attachments.ini
    administrator/language/ro-RO/ro-RO.com_attachments.menu.ini
    administrator/language/ro-RO/ro-RO.plg_attachments_attachments_for_content.ini
    administrator/language/ro-RO/ro-RO.plg_attachments_attachments_plugin_framework.ini
    administrator/language/ro-RO/ro-RO.plg_content_attachments.ini
    administrator/language/ro-RO/ro-RO.plg_editors-xtd_add_attachment.ini
    administrator/language/ro-RO/ro-RO.plg_editors-xtd_insert_attachments_token.ini
    administrator/language/ro-RO/ro-RO.plg_frontend_attachments.ini
    administrator/language/ro-RO/ro-RO.plg_search_attachments.ini
    administrator/language/ro-RO/ro-RO.plg_system_show_attachments.ini
    language/ro-RO/ro-RO.com_attachments.ini
