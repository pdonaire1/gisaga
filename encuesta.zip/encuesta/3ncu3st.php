<?php

$host = "localhost";
$user = "GLADYSGISAGA";
$pw   = "gisagandes";
$db   = "3ncu3est4";

?>
