<?php>
/*
$Preguntas = 
array(
'es_1' => '1. ¿Cómo se caracterizará el desempeño económico global entre 2012 y 2030?',
'es_1_a'=> 'Recuperación de la reciente crisis económica',
'es_1_b'=> 'Alto desempleo en los países desarrollados',
'es_1_c' => 'Desequilibrios de crecimiento en los países desarrollados',
'es_1_d' => 'Crecimiento sostenido de las economías emergentes',
'es_1_e' => 'Mayor crecimiento económico en los países en vías de desarrollo',
'es_1_f' => 'NsNr',

'es_2' => '',
'es_3' => 'jola3'
);
*/
?>
